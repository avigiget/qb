#!/usr/bin/env bash
server=""
wallet_address=""
option=""
cpu_threads=""
cpuTrainer=""
gpuTrainer=""
rig_id=""
autoupdate="false"
hwinfo="false"
pplns="false"
gpu="false"
cpu="false"
idleCmd=""
idleArgs=""
preIdleCmd=""
preIdleArgs=""
postIdleCmd=""
postIdleArgs=""
provider=""
hugepages=""
etoken=""
monero="false"
moneroOpts=""

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --server) server="$2"; shift ;;
        --accesstoken|--payoutid|--account) wallet_address="$2"; option="$1"; shift ;;
        --cputrainer) cpuTrainer="$2"; shift ;;
        --gputrainer) gpuTrainer="$2"; shift ;;
        --rigid) rig_id="$2"; shift ;;
        --threads|--cpu-threads) cpu_threads="$2"; shift ;;
        --autoupdate) autoupdate="true" ;;
        --hwinfo) hwinfo="true" ;;
        --pplns) pplns="true" ;;
        --gpu) gpu="true" ;;
        --cpu) cpu="true" ;;
        --preCommand) preIdleCmd="$2"; shift ;;
        --preArguments) preIdleArgs="$2"; shift ;;
        --command) idleCmd="$2"; shift ;;
        --arguments) idleArgs="$2"; shift ;;
        --postCommand) postIdleCmd="$2"; shift ;;
        --postArguments) postIdleArgs="$2"; shift ;;
        --provider) provider="$2"; shift ;;
        --hugepages) hugepages="$2"; shift ;;
        --etoken|--external-token) etoken="$2"; shift ;;
        --enable-monero|--enable-xmr) monero="true" ;;
        --monero-opts|--xmr-opts) moneroOpts="$2"; shift ;;
        *) echo "Unknown parameter passed: $1"; exit 1 ;;
    esac
    shift
done

if lscpu | egrep -i " avx512f( |$)" 1>/dev/null && \
    lscpu | egrep -i " avx512dq( |$)" 1>/dev/null && \
    lscpu | egrep -i " avx512bw( |$)" 1>/dev/null && \
    lscpu | egrep -i " avx512vl( |$)" 1>/dev/null; then
    HAS_AVX512=1
fi

if [ ! -z "$hugepages" ] && [[ "$hugepages" =~ ^[0-9]+$ ]]; then
    /sbin/sysctl -w vm.nr_hugepages=$hugepages
fi

if [[ -z "$cpuTrainer" ]]; then
    if [[ $HAS_AVX512 ]]; then
        cpuTrainer="AVX512"
    else
        cpuTrainer="AVX2"
    fi
else
    if [[ "$cpuTrainer" =~ ^[Aa][Vv][Xx]2$ ]]; then
        cpuTrainer="AVX2"
    elif [[ "$cpuTrainer" =~ ^[Aa][Vv][Xx]512$ ]]; then
        cpuTrainer="AVX512"
    elif [[ "$cpuTrainer" =~ ^[Ss][Kk][Yy][Ll][Aa][Kk][Ee]$ ]]; then
        cpuTrainer="SKYLAKE"
    elif [[ "$cpuTrainer" =~ ^[Ge][Ee][Nn][Ee][Rr][Ii][Cc]$ ]]; then
        cpuTrainer="GENERIC"
    else
        cpuTrainer="AVX2"
    fi
fi

if [[ -z "$server" ]]; then
    server="wss://wps.qubic.li"
fi

if [[ "$gpuTrainer" =~ ^[Aa][Mm][Dd]$ ]]; then
    gpuTrainer="AMD"
else
    gpuTrainer="CUDA"
fi

if [ -z "$cpu_threads" ]; then
    cpu_threads=$(nproc)
fi

if [ -z "$rig_id" ]; then
    rig_id="mmpOSRig"
fi

JETSKI_PPLNS_TOKEN="eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJJZCI6ImZiZDRlODYyLTkxZWEtNDM1NS04YzFlLTA5Y2M2MmQwNjA2MiIsIk1pbmluZyI6IiIsIm5iZiI6MTcyNjc1NTQxNSwiZXhwIjoxNzU4MjkxNDE1LCJpYXQiOjE3MjY3NTU0MTUsImlzcyI6Imh0dHBzOi8vcXViaWMubGkvIiwiYXVkIjoiaHR0cHM6Ly9xdWJpYy5saS8ifQ.Sl6QKkMeOCK4clB-JnWhai2K1QS0dLxKWfUyTdty39ZcxaR0uCURUhbUmVoTKV_nvVdVunDiqz6Y6Egp0KbENoFYJUSa_Pd83a5Fm5L0lR-9DpaMbYXUHoqdjaZbU-NLJlD4gV1xNPyipmejJerrY7LgBtxk7gNTS0CY_GBb0SbiN4RL-KaTJaFTG31Kno858Oe5MT6JW8CADnhvMhkdewQYuRNsWg6ALrB_OzPMF04IBI0IqdsekvTh5ISe10e60cr0l9hWaYC7v6XFX76cvvnfATU8Ak92YFrgRQJvJ307ju0B-A7syUPNA1BdRo-lojRjshMJvxa_ubrMXo8V8g"
JETSKI_SOLO_TOKEN="eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJJZCI6IjdiMjkxY2Y5LTFiOGItNGYxZi05YWQxLTVkZGRlZmMwNDlhMyIsIk1pbmluZyI6IiIsIm5iZiI6MTcyNzIwNTM0MCwiZXhwIjoxNzU4NzQxMzQwLCJpYXQiOjE3MjcyMDUzNDAsImlzcyI6Imh0dHBzOi8vcXViaWMubGkvIiwiYXVkIjoiaHR0cHM6Ly9xdWJpYy5saS8ifQ.ENyX3VkFkI-qvq04cw7d_yR2M4_LZCNKJg4y-jYwyFkGaZefTFtHMshdCrBYM3TO63X2W9tg_7MHpahDhs-5eEeeJCPoA9TuXvePb0Bz09UwnxhltnE9iE72LoyIPBzWUmwpFcPmLuHtXc98JYZTe9EdMdJyOxhwhjsNgaY_CIy7lsI9F14_gWff8stg8_3eBi-LQrefTUzbr8ps5uNVGU2mZav0ntO07oFDmjxNfNWrZP9u9t54wAdjaTCQY7sN3QjAyZDEyKOPlVvS4OVMERxoYjU0iAC4Ye7NclJW9NKnYpbZk8LF2rbD0dyI1p9sD08awPekzun1xgUQr5BbNA"

if [[ -z "$etoken" ]] && [[ "$pplns" == true ]]; then
    etoken=$JETSKI_PPLNS_TOKEN
elif [[ -z "$etoken" ]] && [[ "$pplns" == false ]]; then
    etoken=$JETSKI_SOLO_TOKEN
fi

if [[ -z "$provider" || "$provider" =~ ^[Qq][Ll][Ii]$ ]]; then
    cat <<-EOF > ./appsettings.json
{
  "ClientSettings": {
    "poolAddress": "${server}/ws",
EOF
    if [[ "$gpu" == "true" && "$cpu" == "false" ]]; then
        cat <<-EOF >> ./appsettings.json
    "trainer": { "gpu": true, "gpuVersion": "$gpuTrainer", "cpu": false },
EOF
    elif [[ "$gpu" == "true" && "$cpu" == "true" ]]; then
        cat <<-EOF >> ./appsettings.json
    "trainer": { "gpu": true, "gpuVersion": "$gpuTrainer", "cpu": true, "cpuVersion": "$cpuTrainer", "cpuThreads": "$cpu_threads" },
EOF
    elif [[ "$gpu" == "false" && "$cpu" == "true" ]]; then
        cat <<-EOF >> ./appsettings.json
    "trainer": { "gpu": false, "cpu": true, "cpuVersion": "$cpuTrainer", "cpuThreads": "$cpu_threads" },
EOF
    else
        cat <<-EOF >> ./appsettings.json
    "trainer": { "gpu": true, "gpuVersion": "$gpuTrainer", "cpu": false },
EOF
    fi

    if [[ ( -n "$preIdleCmd" && -n "$preIdleArgs" ) || ( -n "$idleCmd" && -n "$idleArgs" ) || ( -n "$postIdleCmd" && -n "$postIdleArgs" ) ]]; then
        cat <<-EOF >> ./appsettings.json
    "Idling": { "preCommand": "$preIdleCmd",
                "preCommandArguments": "$preIdleArgs",
                "command": "$idleCmd",
                "arguments": "$idleArgs",
                "postCommand": "$postIdleCmd",
                "postCommandArguments": "$postIdleArgs"
              },
EOF
    else
        cat <<-EOF >> ./appsettings.json
    "Idling": null,
EOF
    fi

    if [ "$hwinfo" == "true" ]; then
        cat <<-EOF >> ./appsettings.json
    "allowHwInfoCollect": true,
EOF
    fi

    if [ "$autoupdate" == "true" ]; then
        cat <<-EOF >> ./appsettings.json
    "autoUpdate": true,
EOF
    fi

    if [ "$pplns" == "true" ]; then
        cat <<-EOF >> ./appsettings.json
    "pps": true,
    "useLiveConnection": true,
EOF
    else
        cat <<-EOF >> ./appsettings.json
    "pps": false,
EOF
    fi

    if [ "$option" == "--accesstoken" ]; then
        cat <<-EOF >> ./appsettings.json
    "accessToken": "$wallet_address",
EOF
    elif [ "$option" == "--payoutid" ]; then
        cat <<-EOF >> ./appsettings.json
    "qubicAddress": "$wallet_address",
EOF
    fi

    if [ ! -z "$rig_id" ]; then
        cat <<-EOF >> ./appsettings.json
    "alias": "$rig_id",
EOF
    fi

    if [ "$monero" == "true" ]; then
        cat <<-EOF >> ./appsettings.json
    "xmrSettings": {
      "disable": false,
      "enableGpu": false,
      "poolAddress": "stratum+tcp://xmr.qubic.li:3333",
      "binaryName": null,
      "customParameters": "$moneroOpts"
    },
EOF
    fi

    cat <<-EOF >> ./appsettings.json
    "displayDetailedHashrates": true
  }
}
EOF

    ./qli-Client
elif [[ "$provider" =~ ^[Ee][Xx][Tt]$ ]] || [[ "$provider" =~ ^[Jj][Ee][Tt][Ss][Kk][Ii]$ ]] || [[ "$provider" =~ ^[Mm][Ii][Nn][Ee][Rr][Ll][Aa][Bb]$ ]]; then
    cat <<-EOF > ./appsettings.json
{
  "ClientSettings": {
    "poolAddress": "${server}/ws/${wallet_address}",
EOF
    if [[ "$gpu" == "true" && "$cpu" == "false" ]]; then
        cat <<-EOF >> ./appsettings.json
    "trainer": { "gpu": true, "gpuVersion": "$gpuTrainer", "cpu": false },
EOF
    elif [[ "$gpu" == "true" && "$cpu" == "true" ]]; then
        cat <<-EOF >> ./appsettings.json
    "trainer": { "gpu": true, "gpuVersion": "$gpuTrainer", "cpu": true, "cpuVersion": "$cpuTrainer", "cpuThreads": "$cpu_threads" },
EOF
    elif [[ "$gpu" == "false" && "$cpu" == "true" ]]; then
        cat <<-EOF >> ./appsettings.json
    "trainer": { "gpu": false, "cpu": true, "cpuVersion": "$cpuTrainer", "cpuThreads": "$cpu_threads" },
EOF
    else
        cat <<-EOF >> ./appsettings.json
    "trainer": { "gpu": true, "gpuVersion": "$gpuTrainer", "cpu": false },
EOF
    fi

    if [[ ( -n "$preIdleCmd" && -n "$preIdleArgs" ) || ( -n "$idleCmd" && -n "$idleArgs" ) || ( -n "$postIdleCmd" && -n "$postIdleArgs" ) ]]; then
        cat <<-EOF >> ./appsettings.json
    "Idling": { "preCommand": "$preIdleCmd",
                "preCommandArguments": "$preIdleArgs",
                "command": "$idleCmd",
                "arguments": "$idleArgs",
                "postCommand": "$postIdleCmd",
                "postCommandArguments": "$postIdleArgs"
              },
EOF
    else
        cat <<-EOF >> ./appsettings.json
    "Idling": null,
EOF
    fi

    if [ "$hwinfo" == "true" ]; then
        cat <<-EOF >> ./appsettings.json
    "allowHwInfoCollect": true,
EOF
    fi

    if [ "$autoupdate" == "true" ]; then
        cat <<-EOF >> ./appsettings.json
    "autoUpdate": true,
EOF
    fi

    if [ "$pplns" == "true" ]; then
        cat <<-EOF >> ./appsettings.json
    "accessToken": "$etoken",
    "pps": true,
    "useLiveConnection": true,
EOF
    else
        cat <<-EOF >> ./appsettings.json
    "accessToken": "$etoken",
    "pps": false,
EOF
    fi

    if [ ! -z "$rig_id" ]; then
        cat <<-EOF >> ./appsettings.json
    "alias": "$rig_id",
EOF
    fi

    if [ "$monero" == "true" ]; then
        cat <<-EOF >> ./appsettings.json
    "xmrSettings": {
      "disable": false,
      "enableGpu": false,
      "poolAddress": "stratum+tcp://xmr.qubic.li:3333",
      "binaryName": null,
      "customParameters": "$moneroOpts"
    },
EOF
    fi

    cat <<-EOF >> ./appsettings.json
    "displayDetailedHashrates": true
  }
}
EOF

    ./qli-Client
else
    echo "No valid provider specified!"
    exit 0
fi
