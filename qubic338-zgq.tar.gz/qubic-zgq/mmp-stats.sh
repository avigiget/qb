#!/usr/bin/env bash
# This file will contain functions related to gathering stats and displaying it for agent
# Agent will have to call mmp-stats.sh which will contain triggers for configuration files and etc.
# Do not add anything static in this file
GPU_COUNT=$1
LOG_FILE=$2
cd `dirname $0`
. mmp-external.conf

switch_profiles() {
    IDLE_STATE=$(tail -n 1 "$LOG_FILE" | grep -cE "PoW is disabled|Qubic is [Ii]dling")
    SW_CNF_FILE=$1
    STATE_FILE="/tmp/idle_state.txt"

    if [[ -f "$STATE_FILE" ]]; then
        LAST_STATE=$(cat "$STATE_FILE")
    else
        LAST_STATE="none"
    fi

    if [[ "$IDLE_STATE" -gt 0 ]]; then
        CURRENT_STATE="inactive"
    else
        CURRENT_STATE="active"
    fi

    if [[ "$CURRENT_STATE" != "$LAST_STATE" || "$LAST_STATE" == "none" ]]; then
        if [[ "$CURRENT_STATE" == "inactive" ]]; then
            ./switch_profile.sh "${SW_CNF_FILE}" inactive > /dev/null 2>&1
        else
            ./switch_profile.sh "${SW_CNF_FILE}" active > /dev/null 2>&1
        fi
    fi

    echo "$CURRENT_STATE" > "$STATE_FILE"
}

get_bus_ids() {
    local vendor_id="$1"
    local bus_ids=$(lspci -n | awk '$2 ~ /^0300|0302:/ && $3 ~ /^'"${vendor_id}"':/ {print $1}')
    local decimal_bus_ids=()

    if [ -z "$bus_ids" ]; then
        exit 1
    fi

    while read -r bus_id; do
        local decimal_bus_id=$((16#${bus_id%%:*}))
        decimal_bus_ids+=("$decimal_bus_id")
    done <<< "$bus_ids"

    echo "${decimal_bus_ids[*]}"
}

get_cards_hashes() {
    hash=''
    if $(tail -n 1 "$LOG_FILE" | grep -qE "PoW is disabled|Qubic is [Ii]dling"); then
        for (( i=0; i < ${GPU_COUNT}; i++ )); do
            hash[$i]=""
        done
    else
        for (( i=0; i < ${GPU_COUNT}; i++ )); do
            hash[$i]=''
            local hs=$(cat "$LOG_FILE" | grep -oP "GPU #${i}: \K\d+"|awk '$1 != "" {print}' |tail -n1)
            hash[$i]=$(echo $hs)
        done
    fi
}

get_miner_shares_ac(){
    ac=0
    local shares=$(cat "$LOG_FILE" | tail -n1 | grep -Eo 'SOL: ([0-9]+)/([0-9]+)')
    if [[ -z "$shares" ]]; then
        shares=$(cat "$LOG_FILE"|grep "gpu.*E[0-9]\{3\}"| awk -F'|' '{print $3}' | awk '{print $1}'|sed -r 's/\x1B\[[0-9;]*[mK]//g' | tail -n 1)
        if [[ "$shares" -ne 0 ]]; then
            ac=$shares
        else
            ac=0
        fi
    else
        if [[ "$shares" =~ SOL:\ ([0-9]+)/([0-9]+) ]]; then
            ac="${BASH_REMATCH[1]}"
        fi
    fi
    echo $ac
}

get_miner_shares_rj(){
    rj=0
    local shares=$(cat "$LOG_FILE" | tail -n1 | grep -Eo 'SOL: ([0-9]+)/([0-9]+)')
    if [[ -z "$shares" ]]; then
        shares=$(cat "$LOG_FILE"|grep "gpu.*E[0-9]\{3\}"| awk -F'|' '{print $4}' | awk '{print $1}'|sed -r 's/\x1B\[[0-9;]*[mK]//g' | tail -n 1)
        if [[ "$shares" -ne 0 ]]; then
            rj=$shares
        else
            rj=0
        fi
    else
        if [[ "$shares" =~ SOL:\ ([0-9]+)/([0-9]+) ]]; then
            ac="${BASH_REMATCH[1]}"
            total="${BASH_REMATCH[2]}"
            rj=$(( total - ac ))
        fi
    fi
    echo $rj
}

get_miner_shares_inv(){
    inv=0
    local inv=$(cat "$LOG_FILE"|grep "gpu.*E[0-9]\{3\}"| awk -F'|' '{print $5}' | awk '{print $1}'|sed -r 's/\x1B\[[0-9;]*[mK]//g' | tail -n 1)
    if [[ -z "$inv" ]]; then
        local inv=0
    fi
    echo $inv
}

get_miner_stats() {
    stats=

    nv_bus_ids=$(get_bus_ids "10de")
    amd_bus_ids=$(get_bus_ids "1002")

    if [[ -n "${nv_bus_ids[@]}" ]]; then
        bus_ids=("${nv_bus_ids[@]}")
    else
        bus_ids=("${amd_bus_ids[@]}")
    fi
    local busid=("${bus_ids[@]}")

    local hash=
    get_cards_hashes                        # hashes array
    local units='hs'                    # hashes units
    # A/R shares by pool
    local ac=$(get_miner_shares_ac)
    local rj=$(get_miner_shares_rj)
    local inv=$(get_miner_shares_inv)

    stats=$(jq -nc \
            --argjson hash "$(echo ${hash[@]} | tr " " "\n" | jq -cs '.')" \
            --argjson busid "$(echo ${busid[@]} | tr " " "\n" | jq -cs '.')" \
            --arg units "$units" \
            --arg ac "$ac" --arg inv "$inv" --arg rj "$rj" \
            --arg miner_version "$EXTERNAL_VERSION" \
            --arg miner_name "$EXTERNAL_NAME" \
        '{$busid, $hash, $units, air: [$ac, $inv, $rj], miner_name: $miner_name, miner_version: $miner_version}')
    # total hashrate in khs
    echo $stats
}

get_miner_stats $GPU_COUNT $LOG_FILE
switch_profiles "/tmp/config.txt"
